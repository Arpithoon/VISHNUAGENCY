import { Navbar } from "./components/layout/Navbar";
import { Hero } from "./components/sections/hero";
import { Services } from "./components/sections/services";

function App() {
  return (
    <div className="app">
      <Navbar />
      <Hero />
      <Services />
    </div>
  );
}

export default App;