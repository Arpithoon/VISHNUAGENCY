import { useEffect, useState } from "react";
import { ArrowUpRight, Menu, X } from "lucide-react";

import "./Navbar.css";

const navItems = [
  {
    label: "Services",
    href: "#services",
  },
  {
    label: "Process",
    href: "#process",
  },
  {
    label: "About",
    href: "#about",
  },
  {
    label: "FAQ",
    href: "#faq",
  },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 24);
    };

    handleScroll();

    window.addEventListener("scroll", handleScroll, {
      passive: true,
    });

    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  useEffect(() => {
    document.body.style.overflow = menuOpen ? "hidden" : "";

    return () => {
      document.body.style.overflow = "";
    };
  }, [menuOpen]);

  const closeMenu = () => {
    setMenuOpen(false);
  };

  return (
    <>
      <header
        className={`navbar ${
          scrolled ? "navbar--scrolled" : ""
        }`}
      >
        <div className="navbar__inner">

          {/* Brand */}
          <a
            href="/"
            className="navbar__brand"
            aria-label="ACY Social Media Expert"
          >
            {/* Logo placeholder — actual logo will be added later */}
            <span className="navbar__brand-placeholder">
              LOGO
            </span>

            <span className="navbar__brand-name">
              ACY
              <span>Social Media Expert</span>
            </span>
          </a>


          {/* Desktop Navigation */}
          <nav
            className="navbar__links"
            aria-label="Main navigation"
          >
            {navItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                className="navbar__link"
              >
                {item.label}
              </a>
            ))}
          </nav>


          {/* Actions */}
          <div className="navbar__actions">

            {/* Desktop CTA */}
            <a
              href="#assessment"
              className="navbar__cta"
            >
              <span>Start a Case</span>

              <ArrowUpRight
                size={14}
                strokeWidth={1.8}
              />
            </a>


            {/* Mobile Menu Button */}
            <button
              type="button"
              className="navbar__menu-button"
              aria-label={
                menuOpen
                  ? "Close navigation menu"
                  : "Open navigation menu"
              }
              aria-expanded={menuOpen}
              onClick={() =>
                setMenuOpen((value) => !value)
              }
            >
              {menuOpen ? (
                <X
                  size={19}
                  strokeWidth={1.8}
                />
              ) : (
                <Menu
                  size={19}
                  strokeWidth={1.8}
                />
              )}
            </button>

          </div>
        </div>
      </header>


      {/* =====================================================
          MOBILE MENU
          ===================================================== */}

      <div
        className={`mobile-menu ${
          menuOpen ? "mobile-menu--open" : ""
        }`}
      >
        <nav
          className="mobile-menu__nav"
          aria-label="Mobile navigation"
        >

          {navItems.map((item, index) => (
            <a
              key={item.label}
              href={item.href}
              className="mobile-menu__link"
              style={{
                transitionDelay: menuOpen
                  ? `${index * 70}ms`
                  : "0ms",
              }}
              onClick={closeMenu}
            >
              <span className="mobile-menu__number">
                0{index + 1}
              </span>

              <span>{item.label}</span>

              <ArrowUpRight
                size={20}
                strokeWidth={1.6}
              />
            </a>
          ))}


          {/* Mobile CTA */}
          <a
            href="#assessment"
            className="mobile-menu__cta"
            onClick={closeMenu}
          >
            <span>Start a Case</span>

            <ArrowUpRight
              size={18}
              strokeWidth={1.8}
            />
          </a>

        </nav>
      </div>
    </>
  );
}