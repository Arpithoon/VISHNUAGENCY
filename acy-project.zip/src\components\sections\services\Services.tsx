import { useEffect, useRef, useState } from "react";
import {
  ArrowDown,
  ArrowUpRight,
  Plus,
} from "lucide-react";

import ServiceDoor, {
  type ServiceDoorData,
} from "./ServiceDoor";

import "./Services.css";


/* =========================================================
   SERVICE DATA
   ========================================================= */

const services: ServiceDoorData[] = [
  {
    number: "01",
    category: "ACCOUNT ACCESS",
    title: "Recover",
    shortDescription:
      "Structured assistance for difficult account access and recovery situations.",
    description:
      "When normal recovery routes aren't resolving the problem, we help assess the situation, organize the relevant information and navigate the appropriate platform recovery process.",
    services: [
      "Account recovery assistance",
      "Login & access issues",
      "Recovery workflow guidance",
      "Account ownership support",
    ],
    platforms: [
      "Instagram",
      "Facebook",
      "YouTube",
      "Other platforms",
    ],
    accent: "#ff7a00",
  },

  {
    number: "02",
    category: "ACCOUNT RESTORATION",
    title: "Restore",
    shortDescription:
      "Support for disabled, suspended and removed account situations.",
    description:
      "Account restrictions can be confusing and difficult to navigate. We help understand the situation and prepare the appropriate information for available platform review and appeal processes.",
    services: [
      "Disabled account assistance",
      "Suspended account support",
      "Account removal issues",
      "Appeal process guidance",
    ],
    platforms: [
      "Instagram",
      "Facebook",
      "YouTube",
      "Other platforms",
    ],
    accent: "#ff9d3d",
  },

  {
    number: "03",
    category: "PLATFORM VERIFICATION",
    title: "Verify",
    shortDescription:
      "Professional guidance around verification and platform presence.",
    description:
      "We help clients understand platform verification requirements, prepare their profiles and organize the information needed for a stronger, legitimate verification application.",
    services: [
      "Verification guidance",
      "Profile preparation",
      "Application assistance",
      "Presence optimization",
    ],
    platforms: [
      "Instagram",
      "Facebook",
      "YouTube",
      "Other platforms",
    ],
    accent: "#ffd166",
  },

  {
    number: "04",
    category: "ACCOUNT SECURITY",
    title: "Secure",
    shortDescription:
      "Support for compromised accounts and stronger account security.",
    description:
      "If an account has been compromised or its security needs attention, we help assess the situation and work through the appropriate recovery and security steps.",
    services: [
      "Compromised account support",
      "Account security guidance",
      "Access recovery",
      "Security review",
    ],
    platforms: [
      "Instagram",
      "Facebook",
      "WhatsApp",
      "Telegram",
    ],
    accent: "#8be28b",
  },

  {
    number: "05",
    category: "SOCIAL GROWTH",
    title: "Grow",
    shortDescription:
      "Strategies designed to build a stronger and more effective online presence.",
    description:
      "Growth is more than numbers. We focus on positioning, content direction and audience strategy to help create a stronger and more consistent social presence.",
    services: [
      "Growth strategy",
      "Online presence optimization",
      "Content direction",
      "Audience strategy",
    ],
    platforms: [
      "Instagram",
      "Facebook",
      "YouTube",
      "Snapchat",
    ],
    accent: "#65d9ff",
  },

  {
    number: "06",
    category: "SOCIAL MEDIA MANAGEMENT",
    title: "Manage",
    shortDescription:
      "Social media management and SMM support across major platforms.",
    description:
      "For clients who need ongoing support, we provide structured social media management focused on consistency, positioning, platform strategy and day-to-day account operations.",
    services: [
      "Social media management",
      "SMM services",
      "Account management",
      "Platform strategy",
    ],
    platforms: [
      "Instagram",
      "Facebook",
      "YouTube",
      "Snapchat",
      "WhatsApp",
      "Telegram",
    ],
    accent: "#b98cff",
  },
];


/* =========================================================
   COMPONENT
   ========================================================= */

export default function Services() {
  const sectionRef = useRef<HTMLElement | null>(null);

  const [openService, setOpenService] =
    useState<string | null>(null);

  const [visibleDoors, setVisibleDoors] =
    useState<number[]>([]);


  /* =======================================================
     REVEAL OBSERVER
     ======================================================= */

  useEffect(() => {
    const section = sectionRef.current;

    if (!section) {
      return;
    }

    const doors =
      Array.from(
        section.querySelectorAll<HTMLElement>(
          ".service-door",
        ),
      );

    if (!doors.length) {
      return;
    }

    const observer =
      new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (!entry.isIntersecting) {
              return;
            }

            const index = doors.indexOf(
              entry.target as HTMLElement,
            );

            if (index === -1) {
              return;
            }

            setVisibleDoors((current) => {
              if (current.includes(index)) {
                return current;
              }

              return [...current, index];
            });

            observer.unobserve(entry.target);
          });
        },
        {
          threshold: 0.12,
          rootMargin: "0px 0px -60px 0px",
        },
      );

    doors.forEach((door) => {
      observer.observe(door);
    });

    return () => {
      observer.disconnect();
    };
  }, []);


  /* =======================================================
     SERVICE TOGGLE
     ======================================================= */

  const handleToggle = (number: string) => {
    setOpenService((current) =>
      current === number
        ? null
        : number,
    );
  };


  /* =======================================================
     OPEN FIRST / CLOSE ALL
     ======================================================= */

  const openFirstService = () => {
    setOpenService(services[0].number);
  };

  const closeAllServices = () => {
    setOpenService(null);
  };


  return (
    <section
      ref={sectionRef}
      id="services"
      className="services"
      aria-labelledby="services-title"
    >

      {/* ===================================================
          BACKGROUND ATMOSPHERE
          =================================================== */}

      <div
        className="services__background"
        aria-hidden="true"
      >
        <div className="services__glow" />
        <div className="services__grid" />

        <div className="services__orb services__orb--one" />
        <div className="services__orb services__orb--two" />
      </div>


      {/* ===================================================
          MAIN CONTAINER
          =================================================== */}

      <div className="services__container">


        {/* =================================================
            SECTION HEADER
            ================================================= */}

        <header className="services__header">

          <div className="services__eyebrow">
            <span className="services__eyebrow-line" />

            <span>
              02 / Services
            </span>

            <span className="services__eyebrow-status">
              <span className="services__status-dot" />
              Available
            </span>
          </div>


          <div className="services__heading-row">

            <div className="services__heading">

              <h2
                id="services-title"
                className="services__title"
              >
                Problems are
                <span> different.</span>

                <br />

                So are the
                <span> solutions.</span>
              </h2>

            </div>


            <div className="services__intro">

              <p>
                From account recovery and platform
                issues to social media management and
                growth — explore the areas where ACY
                can help.
              </p>


              <button
                type="button"
                className="services__explore"
                onClick={openFirstService}
              >
                <span>
                  Explore services
                </span>

                <span className="services__explore-icon">
                  <ArrowDown
                    size={14}
                    strokeWidth={1.5}
                  />
                </span>
              </button>

            </div>

          </div>


          {/* =============================================
              META ROW
              ============================================= */}

          <div className="services__meta">

            <span>
              {String(services.length).padStart(2, "0")}
              {" "}
              service categories
            </span>

            <span className="services__meta-line" />

            <span>
              Select a door to explore
            </span>

          </div>

        </header>


        {/* =================================================
            SERVICE DOORS
            ================================================= */}

        <div className="services__doors">

          {services.map((service, index) => (
            <div
              key={service.number}
              className={[
                "services__door-wrapper",
                visibleDoors.includes(index)
                  ? "services__door-wrapper--visible"
                  : "",
              ].join(" ")}
              style={{
                "--door-index": index,
              } as React.CSSProperties}
            >

              <ServiceDoor
                service={service}
                isOpen={
                  openService === service.number
                }
                onToggle={() =>
                  handleToggle(service.number)
                }
              />

            </div>
          ))}

        </div>


        {/* =================================================
            SERVICE CONTROLS
            ================================================= */}

        <div className="services__controls">

          <button
            type="button"
            className="services__control"
            onClick={openFirstService}
          >
            <Plus
              size={14}
              strokeWidth={1.5}
            />

            <span>
              Open first service
            </span>
          </button>


          <button
            type="button"
            className="services__control"
            onClick={closeAllServices}
          >
            <span>
              Close all
            </span>

            <span className="services__control-line" />
          </button>

        </div>


        {/* =================================================
            BOTTOM CTA
            ================================================= */}

        <div
          id="assessment"
          className="services__footer"
        >

          <div className="services__footer-number">
            02
          </div>


          <div className="services__footer-copy">

            <span className="services__footer-label">
              Something else?
            </span>

            <p>
              Not every case fits neatly into a
              category. Tell us what you're dealing
              with and we'll help identify the right
              direction.
            </p>

          </div>


          <a
            href="#contact"
            className="services__footer-button"
          >
            <span>
              Discuss your case
            </span>

            <span className="services__footer-button-icon">
              <ArrowUpRight
                size={16}
                strokeWidth={1.6}
              />
            </span>
          </a>

        </div>


        {/* =================================================
            SECTION END MARKER
            ================================================= */}

        <div className="services__end">

          <span>
            ACY / SERVICES
          </span>

          <span className="services__end-line" />

          <span>
            02 — 06
          </span>

        </div>

      </div>
    </section>
  );
}
