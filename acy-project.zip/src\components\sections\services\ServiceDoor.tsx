import {
  ArrowUpRight,
  ChevronDown,
  Plus,
} from "lucide-react";
import {
  useRef,
  useState,
  type CSSProperties,
  type PointerEvent,
} from "react";

import "./ServiceDoor.css";

export interface ServiceDoorData {
  number: string;
  category: string;
  title: string;
  shortDescription: string;
  description: string;
  services: string[];
  platforms: string[];
  accent?: string;
}

interface ServiceDoorProps {
  service: ServiceDoorData;
  isOpen: boolean;
  onToggle: () => void;
}

interface DoorStyle extends CSSProperties {
  "--door-mx"?: string;
  "--door-my"?: string;
  "--door-rx"?: string;
  "--door-ry"?: string;
  "--door-accent"?: string;
}

export default function ServiceDoor({
  service,
  isOpen,
  onToggle,
}: ServiceDoorProps) {
  const rootRef = useRef<HTMLElement | null>(null);

  const [hovered, setHovered] = useState(false);

  const [motion, setMotion] = useState<DoorStyle>({
    "--door-mx": "0px",
    "--door-my": "0px",
    "--door-rx": "0deg",
    "--door-ry": "0deg",
    "--door-accent": service.accent ?? "#ff7a00",
  });


  /* =====================================================
     POINTER / 3D MOTION
     ===================================================== */

  const handlePointerMove = (
    event: PointerEvent<HTMLElement>,
  ) => {
    if (
      event.pointerType === "touch" ||
      !rootRef.current
    ) {
      return;
    }

    const rect =
      rootRef.current.getBoundingClientRect();

    const x =
      (event.clientX - rect.left) /
        rect.width -
      0.5;

    const y =
      (event.clientY - rect.top) /
        rect.height -
      0.5;

    setMotion((current) => ({
      ...current,

      "--door-mx": `${x * 12}px`,
      "--door-my": `${y * 8}px`,

      "--door-rx": `${y * -2.5}deg`,
      "--door-ry": `${x * 3.5}deg`,
    }));
  };


  const handlePointerEnter = (
    event: PointerEvent<HTMLElement>,
  ) => {
    if (event.pointerType !== "touch") {
      setHovered(true);
    }
  };


  const handlePointerLeave = () => {
    setHovered(false);

    setMotion((current) => ({
      ...current,

      "--door-mx": "0px",
      "--door-my": "0px",

      "--door-rx": "0deg",
      "--door-ry": "0deg",
    }));
  };


  /* =====================================================
     RENDER
     ===================================================== */

  return (
    <article
      ref={rootRef}
      className={[
        "service-door",
        isOpen
          ? "service-door--open"
          : "",
        hovered
          ? "service-door--hovered"
          : "",
      ]
        .filter(Boolean)
        .join(" ")}
      style={motion}
      onPointerMove={handlePointerMove}
      onPointerEnter={handlePointerEnter}
      onPointerLeave={handlePointerLeave}
    >

      {/* =================================================
          ATMOSPHERE
          ================================================= */}

      <div
        className="service-door__ambient"
        aria-hidden="true"
      />

      <div
        className="service-door__scan"
        aria-hidden="true"
      />


      {/* =================================================
          MAIN DOOR BUTTON
          ================================================= */}

      <button
        type="button"
        className="service-door__trigger"
        onClick={onToggle}
        aria-expanded={isOpen}
        aria-controls={`service-${service.number}`}
      >

        {/* ===============================================
            NUMBER
            =============================================== */}

        <span
          className="service-door__number"
          aria-hidden="true"
        >
          <span>/</span>
          {service.number}
        </span>


        {/* ===============================================
            DOOR VISUAL
            =============================================== */}

        <span
          className="service-door__visual"
          aria-hidden="true"
        >

          <span className="service-door__door-shadow" />

          <span className="service-door__door-body">

            <span className="service-door__glass" />

            <span className="service-door__grid" />

            <span className="service-door__frame" />

            <span className="service-door__frame-inner" />


            {/* -------------------------------------------
                DOOR BRAND
                ------------------------------------------- */}

            <span className="service-door__brand">
              ACY
            </span>


            {/* -------------------------------------------
                DOOR NUMBER
                ------------------------------------------- */}

            <span className="service-door__door-number">
              {service.number}
            </span>


            {/* -------------------------------------------
                CENTRAL SYMBOL
                ------------------------------------------- */}

            <span className="service-door__symbol">

              <span className="service-door__symbol-ring" />

              <span className="service-door__symbol-core">
                <span />
              </span>

              <span className="service-door__symbol-ray ray-one" />
              <span className="service-door__symbol-ray ray-two" />
              <span className="service-door__symbol-ray ray-three" />

            </span>


            {/* -------------------------------------------
                HANDLE
                ------------------------------------------- */}

            <span className="service-door__handle">

              <span className="service-door__handle-bar" />

              <span className="service-door__handle-dot" />

            </span>


            {/* -------------------------------------------
                LIGHT EDGE
                ------------------------------------------- */}

            <span className="service-door__light-edge" />

          </span>


          {/* ---------------------------------------------
              SIDE DEPTH
              --------------------------------------------- */}

          <span className="service-door__depth" />

        </span>


        {/* ===============================================
            MAIN INFORMATION
            =============================================== */}

        <span className="service-door__content">

          <span className="service-door__category">
            {service.category}
          </span>


          <span className="service-door__title">
            {service.title}
          </span>


          <span className="service-door__description">
            {service.shortDescription}
          </span>


          <span className="service-door__meta">

            <span className="service-door__meta-line" />

            <span>
              ACY / SOCIAL MEDIA
            </span>

          </span>

        </span>


        {/* ===============================================
            ACTION
            =============================================== */}

        <span className="service-door__action">

          <span className="service-door__action-label">
            {isOpen
              ? "Close"
              : "Explore"}
          </span>


          <span className="service-door__action-button">

            {isOpen ? (
              <ChevronDown
                size={19}
                strokeWidth={1.25}
              />
            ) : (
              <Plus
                size={19}
                strokeWidth={1.25}
              />
            )}

          </span>

        </span>

      </button>


      {/* =================================================
          EXPANDED INFORMATION
          ================================================= */}

      <div
        id={`service-${service.number}`}
        className="service-door__details"
        aria-hidden={!isOpen}
      >

        <div className="service-door__details-inner">


          {/* =============================================
              OVERVIEW
              ============================================= */}

          <div className="service-door__overview">

            <div className="service-door__label">
              <span>
                CASE OVERVIEW
              </span>

              <span className="service-door__label-line" />
            </div>


            <p className="service-door__overview-text">
              {service.description}
            </p>


            <a
              href="#contact"
              className="service-door__case-link"
              tabIndex={
                isOpen
                  ? 0
                  : -1
              }
            >

              <span>
                Discuss your case
              </span>

              <span className="service-door__case-icon">
                <ArrowUpRight
                  size={17}
                  strokeWidth={1.4}
                />
              </span>

            </a>

          </div>


          {/* =============================================
              WHAT WE HANDLE
              ============================================= */}

          <div className="service-door__column">

            <div className="service-door__label">

              <span>
                WHAT WE CAN HELP WITH
              </span>

              <span className="service-door__label-line" />

            </div>


            <ul className="service-door__list">

              {service.services.map(
                (item, index) => (
                  <li key={item}>

                    <span className="service-door__list-number">
                      {String(
                        index + 1,
                      ).padStart(2, "0")}
                    </span>

                    <span className="service-door__list-dot" />

                    <span className="service-door__list-text">
                      {item}
                    </span>

                  </li>
                ),
              )}

            </ul>

          </div>


          {/* =============================================
              PLATFORMS
              ============================================= */}

          <div className="service-door__column">

            <div className="service-door__label">

              <span>
                PLATFORMS
              </span>

              <span className="service-door__label-line" />

            </div>


            <div className="service-door__platforms">

              {service.platforms.map(
                (platform) => (
                  <span
                    key={platform}
                    className="service-door__platform"
                  >
                    {platform}
                  </span>
                ),
              )}

            </div>


            <a
              href="#contact"
              className="service-door__secondary-link"
              tabIndex={
                isOpen
                  ? 0
                  : -1
              }
            >
              <span>
                Start a case
              </span>

              <ArrowUpRight
                size={14}
                strokeWidth={1.5}
              />
            </a>

          </div>

        </div>

      </div>


      {/* =================================================
          BOTTOM ACCENT
          ================================================= */}

      <div
        className="service-door__bottom-line"
        aria-hidden="true"
      >
        <span />
      </div>

    </article>
  );
}